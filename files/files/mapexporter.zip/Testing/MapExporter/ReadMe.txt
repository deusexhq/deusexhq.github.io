== Map T3D exporter ==

These scripts will export all maps you want to .T3D text files so you can look through them in a text editor looking for various properties/classes.
The map exporter uses Han's Launch that has an -editor switch that opens the launcher in UED mode that can process a set of commands from a file.

= Make a MapList =
Run MakeMapList.bat that will create a list of all .dx maps in ..\..\Maps. Modify the path here if you want it to use another folder like ..\..\GMDX\Maps. Open and edit the MapList.txt that was just generated to make sure it only contains the maps you want to export. For instance you might not care about MP maps or DXOnly.

= Make .exec files =
Run MakeExportScript.bat that will generate an .exec file. It's like a script for UED and it will process and execute each line in an editor context. However due to limitations of the editor you will probably need to split up the .exec into several files. This will be some trial and error about how many files you'll need. When the editor crashes when exporting something, look at what map it's crashing on and move the remaining lines in the .exec file to a new .exec file.

For instance if it's crashing on 06_HongKong_WanChai_Underworld, then move all remaining lines just before the MAP LOAD FILE=06_HongKong_WanChai_Underworld to a new .exec file. Remember to start each .exec file with CAMERA CLOSE FREE and to name them MapExport*.exec, since this is what the next script will look for.

Explanation: 
This is because some classes have names that will be reused across different classes. Normally each actor gets a name that is [ClassName][sequential digit], like Light1 for Light.uc actors. This works fine unless the class name ends with a digit, like Pan1.uc and Pan2.uc. In that case an actor of either Pan class will get Pan[sequential digit] like Pan0. If you have a map where there is an actor with the name Pan0 of the Pan2 class, and then open another map that also contains a Pan0 actor but of the Pan1 class the editor gets confused and crashes. This is most likely cause it's reusing the memory allocated for the previous actor (since it assumes two actors with the same name must be of the same class). Just changing the properties of the actor instead of deallocating all of the memory and then reallocating new memory (that probably takes way longer than just swapping out the properties on existing actors). This fails if the two actors are not of the same class (Pan0 was first Pan1 and then Pan2).

= Supply a custom Launch.ini =
If you are exporting a mod that has custom paths (ie not using vanilla folders) then you need to supply a custom Launch.ini with paths set to load the mod. Just copy Default.ini and rename it Launch.ini, then add the mod's Path lines to Launch.ini. In almost all cases this will be enough to open the maps in the editor. Custom RootWidnows, GameInfo, Players, GameEngine etc shouldn't affect the ability to correctly open the maps in the editor. Those should only matter if trying to play the mod.

= Run ExportMaps.bat =
If you are running all the scripts in DX\MapExporter\Testing then it should suffice to just run the ExportMaps.bat script as it is. Maps will be exported to the ExportedMaps folder.